
package Listas_simples;
import java.text.DecimalFormat;
import java.awt.Font;
import javax.swing.JOptionPane;

public class Listas extends javax.swing.JFrame {
public class Nodo{
String codigo;
String nombre;
String sueldo;
Nodo sig;

    public Nodo(String codigo, String nombre, String sueldo) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.sueldo = sueldo;
    }
}

public Nodo ini,fin;
public Nodo pFound;
int num=0;
    public Listas() {
        initComponents();
    }
    
void Encabezado(){
TxaReporte.setFont(new Font("monospaced",Font.PLAIN,12));
TxaReporte.setText("");
TxaReporte.append("");
TxaReporte.append("     Nº |  CODIGO   NOMBRES Y APELLIDOS             SUELDOS\n");
TxaReporte.append("------------------------------------------------------------\n");
}    
void Habilitar(){
btnActualizar.setEnabled(true);
btnEliminar.setEnabled(true);
btnGuardar.setEnabled(false);
}    

void Deshabilitar(){
btnActualizar.setEnabled(false);
btnEliminar.setEnabled(false);
btnGuardar.setEnabled(true);
}  

void LimpiarEntradas(){
txtCodigo.setText("");
txtNombre.setText("");
txtSueldo.setText("");
txtCodigo.requestFocus();
}  

void VerDatos(){
String cod,nom,s;
Nodo aux=ini;
num=0;

Encabezado();

while(aux!=null){
cod=aux.codigo;
nom=aux.nombre;
s=aux.sueldo;
num++;
String numera = String.valueOf(num);

for (int i = String.valueOf(num).length(); i<5;i++){
numera = " "+numera;   }

for (int i = cod.length(); i<12;i++){
cod = cod+" ";    }

for (int i = nom.length(); i<28;i++){
nom = nom+" ";    }

DecimalFormat df2 = new DecimalFormat("####.00");
s = df2.format(Double.valueOf(s));

for (int i = s.length(); i<12;i++){
s = " "+s;    }

TxaReporte.append(numera +" | "+ cod+nom + s +"\n");
aux=aux.sig;
 }
}

Nodo Buscar(Nodo inicio,String cod){
Nodo pos=inicio;

    while(pos!=null && !cod.equalsIgnoreCase(pos.codigo))
    pos=pos.sig;      
    return pos;
}

Nodo InsertarInicio(Nodo inicio, String cod,String nom,String suel){
Nodo nuevo=new Nodo(cod,nom,suel);

nuevo.sig=inicio;
inicio=nuevo;
return inicio;
}

void Eliminar (Nodo actual) {
Nodo anterior=ini;

while(anterior.sig!=actual && anterior.sig!=null)
{ anterior=anterior.sig; }

if(actual!=null)
{ if(anterior==actual) ini=actual.sig; 
else anterior.sig= actual.sig;
}
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtCodigo = new javax.swing.JTextField();
        txtSueldo = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        btnConsultar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnReestaurar = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        TxaReporte = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Swis721 BT", 0, 18)); // NOI18N
        jLabel1.setText("PROGRAMA DE BUSQUEDA Y GRABADO DE DATOS VALEJO BETA PROYECT");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(30, 30, 560, 50);
        getContentPane().add(txtNombre);
        txtNombre.setBounds(110, 150, 282, 22);

        jLabel2.setText("NOMBRE");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(20, 150, 49, 19);

        jLabel3.setText("SUELDO");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(20, 210, 49, 16);
        getContentPane().add(txtCodigo);
        txtCodigo.setBounds(110, 100, 176, 22);
        getContentPane().add(txtSueldo);
        txtSueldo.setBounds(110, 210, 176, 22);

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardar);
        btnGuardar.setBounds(450, 80, 85, 50);

        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });
        getContentPane().add(btnActualizar);
        btnActualizar.setBounds(540, 80, 82, 50);

        btnConsultar.setText("Consultar");
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });
        getContentPane().add(btnConsultar);
        btnConsultar.setBounds(450, 130, 85, 40);

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEliminar);
        btnEliminar.setBounds(540, 130, 82, 40);

        btnReestaurar.setText("Reestaurar");
        btnReestaurar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReestaurarActionPerformed(evt);
            }
        });
        getContentPane().add(btnReestaurar);
        btnReestaurar.setBounds(450, 170, 85, 40);

        jButton6.setText("Salir");
        getContentPane().add(jButton6);
        jButton6.setBounds(540, 170, 82, 40);

        TxaReporte.setColumns(20);
        TxaReporte.setRows(5);
        jScrollPane2.setViewportView(TxaReporte);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(40, 250, 470, 210);

        jLabel4.setText("CODIGO");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(20, 100, 45, 16);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        String cod=txtCodigo.getText();
        String nom=txtNombre.getText().toUpperCase();
        String suel=txtSueldo.getText();
        
        ini=InsertarInicio(ini,cod,nom,suel);
        LimpiarEntradas();
        VerDatos();
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        pFound.codigo=txtCodigo.getText();
        pFound.nombre=txtNombre.getText();
        pFound.sueldo=txtSueldo.getText();
        LimpiarEntradas();
        Deshabilitar();
        VerDatos();
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        String cod=txtCodigo.getText();
        if(cod.equalsIgnoreCase("")){
        JOptionPane.showMessageDialog(this,"Ingrese un codigo por favor");
        } else {
        
        pFound=Buscar(ini,cod);
        if(pFound!=null){
           txtNombre.setText(pFound.nombre);
           txtSueldo.setText(pFound.sueldo);
        
           Habilitar();
           
        } else {
            JOptionPane.showMessageDialog(this,"El código: "+cod + ", no esta en la lista");
        }
      }  
    }//GEN-LAST:event_btnConsultarActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        Encabezado();
        Deshabilitar();
    }//GEN-LAST:event_formWindowOpened

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        Eliminar(pFound);
        LimpiarEntradas();
        VerDatos();
        if(pFound!=null)
          JOptionPane.showMessageDialog(this,"la lista esta vacía");  
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnReestaurarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReestaurarActionPerformed
        LimpiarEntradas();
        Deshabilitar();
    }//GEN-LAST:event_btnReestaurarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Listas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Listas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Listas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Listas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Listas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea TxaReporte;
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnReestaurar;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtSueldo;
    // End of variables declaration//GEN-END:variables
}
